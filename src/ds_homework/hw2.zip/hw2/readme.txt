a.c 是第一題
b.c 是第二題
    - 有fast_transpose跟matrix_multiplication

c.c是第三題，
輸入一個N會輸出0~N所有不可能的排列
作法:
    先生成0 ~ N 的所有排列，然後檢查這可不可能